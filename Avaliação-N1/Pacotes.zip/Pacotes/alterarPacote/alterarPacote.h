#ifndef ALTERARPACOTE_H
#define ALTERARPACOTE_H

#include "../incluirPacote/incluirPacote.h"

void alterarPacote(struct PACOTE **inicio, int idProd);

#endif