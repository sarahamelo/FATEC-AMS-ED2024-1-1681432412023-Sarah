#ifndef RASTREARPACOTE_H
#define RASTREARPACOTE_H

#include "../incluirPacote/incluirPacote.h"

void rastrearPacote(struct PACOTE *inicio, int id);

#endif