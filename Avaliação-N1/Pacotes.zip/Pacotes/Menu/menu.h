#ifndef MENU_H
#define MENU_H

#include "../incluirPacote/incluirPacote.h"
#include "../alterarPacote/alterarPacote.h"
#include "../rastrearPacote/rastrearPacote.h"

void exibirMenu(struct PACOTE **inicio);

#endif