/* -------------------------------------------
Fatec São Caetano do Sul - Estrutura de Dados
Professor: Carlos Veríssimo
Proposta: Sistema de Gerenciamento de Contatos
Autor: Equipe 2
Data: 28/05/2024
------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Contato {
    char nome[50];
    char telefone[15];
    char email[50];
};

struct Node {
    struct Contato contato;
    struct Node* proximo;
};

//Adicionar
struct Node* adicionarContatoOrdenado(struct Node* lista, struct Contato novoContato) {
    struct Node* novoNo = (struct Node*)malloc(sizeof(struct Node));
    novoNo->contato = novoContato;
    novoNo->proximo = NULL;

    // Se a lista estiver vazia ou o novo contato vem antes do primeiro contato na lista
    if (lista == NULL || strcmp(novoContato.nome, lista->contato.nome) < 0) {
        novoNo->proximo = lista;
        return novoNo;
    }

    // Encontrar o ponto de inserção
    struct Node* anterior = NULL;
    struct Node* atual = lista;
    while (atual != NULL && strcmp(novoContato.nome, atual->contato.nome) > 0) {
        anterior = atual;
        atual = atual->proximo;
    }

    // Inserir o novo nó entre o nó anterior e o nó atual
    anterior->proximo = novoNo;
    novoNo->proximo = atual;

    return lista;
}

//Exibir
void exibirLista(struct Node* lista) {
    struct Node* atual = lista;
    while (atual != NULL) {
        printf("Nome: %s\n", atual->contato.nome);
        printf("Telefone: %s\n", atual->contato.telefone);
        printf("Email: %s\n", atual->contato.email);
        printf("\n");
        atual = atual->proximo;
    }
}

int main() {

    struct Node* lista = NULL;
    // Adicionando alguns contatos para teste
    struct Contato contato1 = {"Uulano", "123456789", "fulano@example.com"};
    struct Contato contato2 = {"Giclano", "987654321", "ciclano@example.com"};
    struct Contato contato3 = {"Geltrano", "456123789", "beltrano@example.com"};

    // Adicionando contatos à lista (em ordem alfabética)
    lista = adicionarContatoOrdenado(lista, contato1);
    lista = adicionarContatoOrdenado(lista, contato2);
    lista = adicionarContatoOrdenado(lista, contato3);

    // Exibindo a lista de contatos
    exibirLista(lista);

    return 0;
}
